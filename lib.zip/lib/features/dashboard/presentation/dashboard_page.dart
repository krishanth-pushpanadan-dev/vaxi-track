import 'package:flutter/material.dart';
import 'package:vaxi_track/app/app_colors.dart';
import 'package:vaxi_track/app/app_routes.dart';

import '../../authentication/models/user_model.dart';
import '../../authentication/models/role_permissions.dart';
import '../../authentication/services/auth_service.dart';

import '../../alerts/data/alert_dummy_data.dart';
import '../../alerts/models/alert_model.dart' as alert_model;

import '../../order_requests/presentation/marketplace_page.dart';
import '../../order_requests/presentation/supplier_products_page.dart';
import '../widgets/dashboard_header.dart';
import '../widgets/section_header.dart';
import '../widgets/stat_card.dart';
import '../widgets/sensor_card.dart';
import '../widgets/quick_action_card.dart';
import '../widgets/alert_card.dart';
import '../widgets/device_card.dart';
import '../widgets/activity_tile.dart';
import '../widgets/batch_summary_card.dart';
import '../widgets/bottom_nav_bar.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  // ================================================================
  // SERVICES & STATE
  // ================================================================

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final AuthService _authService = AuthService();

  final int _currentIndex = 0;

  UserModel? get currentUser => _authService.currentUser;

  // Shared alert data drives the dashboard badge, overview, and recent alerts.
  int get _activeAlertCount => alertList
      .where((alert) => alert.status == alert_model.AlertStatus.active)
      .length;

  int get _criticalAlertCount => alertList
      .where(
        (alert) =>
            alert.status == alert_model.AlertStatus.active &&
            alert.severity == alert_model.AlertSeverity.critical,
      )
      .length;

  int get _unreadAlertCount => alertList
      .where(
        (alert) =>
            alert.status == alert_model.AlertStatus.active &&
            !alert.acknowledged,
      )
      .length;

  List<alert_model.AlertModel> get _recentActiveAlerts => alertList
      .where((alert) => alert.status == alert_model.AlertStatus.active)
      .take(3)
      .toList();

  AlertSeverity _dashboardSeverity(alert_model.AlertSeverity severity) {
    switch (severity) {
      case alert_model.AlertSeverity.critical:
        return AlertSeverity.critical;
      case alert_model.AlertSeverity.warning:
        return AlertSeverity.warning;
      case alert_model.AlertSeverity.info:
        return AlertSeverity.info;
    }
  }

  // ================================================================
  // REFRESH
  // ================================================================

  Future<void> refreshDashboard() async {
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    setState(() {});

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text("Dashboard refreshed")));
  }

  // ================================================================
  // BOTTOM NAVIGATION
  // ================================================================

  void _onBottomNavTap(int index) {
    if (index == _currentIndex) return;

    final user = currentUser;

    switch (index) {
      case 0:
        break;

      case 1:
        if (user != null && RolePermissions.canViewDevices(user.role)) {
          Navigator.pushReplacementNamed(context, AppRoutes.devices);
        } else {
          _showAccessDenied();
        }
        break;

      case 2:
        Navigator.pushReplacementNamed(context, AppRoutes.batches);
        break;

      case 3:
        Navigator.pushReplacementNamed(context, AppRoutes.alerts);
        break;
    }
  }

  // ================================================================
  // ACCESS DENIED
  // ================================================================

  void _showAccessDenied() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("You don't have permission to access this feature."),
      ),
    );
  }

  // ================================================================
  // ORDER REQUEST NAVIGATION
  // ================================================================

  void _openOrderRequest() {
    final user = currentUser;

    if (user == null) {
      _showAccessDenied();
      return;
    }

    if (!RolePermissions.canViewOrderRequests(user.role)) {
      _showAccessDenied();
      return;
    }

    // --------------------------------------------------------------
    // PHARMACIST
    // --------------------------------------------------------------
    // Pharmacist starts from the Supply Marketplace.
    //
    // Flow:
    //
    // Marketplace
    //      ↓
    // Product
    //      ↓
    // Product Details
    //      ↓
    // Request Product
    //      ↓
    // Create Order
    //      ↓
    // My Orders
    // --------------------------------------------------------------

    if (user.role == UserRole.pharmacist) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const MarketplacePage()),
      );

      return;
    }

    // --------------------------------------------------------------
    // OTHER ORDERING ROLES
    // --------------------------------------------------------------
    // Admin, Warehouse Staff and Sales Representative
    // can access Order Requests.
    // --------------------------------------------------------------

    Navigator.pushNamed(context, AppRoutes.orderRequests);
  }

  // ================================================================
  // SUPPLIER PRODUCTS NAVIGATION
  // ================================================================

  void _openSupplierProducts() {
    final user = currentUser;

    if (user == null) {
      _showAccessDenied();
      return;
    }

    if (!RolePermissions.canViewSupplierProducts(user.role)) {
      _showAccessDenied();
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const SupplierProductsPage()),
    );
  }

  // ================================================================
  // MARKETPLACE NAVIGATION
  // ================================================================

  void _openMarketplace() {
    final user = currentUser;

    if (user == null) {
      _showAccessDenied();
      return;
    }

    if (!RolePermissions.canViewOrderRequests(user.role)) {
      _showAccessDenied();
      return;
    }

    if (user.role != UserRole.pharmacist) {
      _showAccessDenied();
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const MarketplacePage()),
    );
  }

  // ================================================================
  // LOGOUT
  // ================================================================

  void _logout() {
    _authService.logout();

    Navigator.pushNamedAndRemoveUntil(
      context,
      AppRoutes.login,
      (route) => false,
    );
  }

  // ================================================================
  // BUILD
  // ================================================================

  @override
  Widget build(BuildContext context) {
    final user = currentUser;

    return Scaffold(
      key: _scaffoldKey,

      backgroundColor: const Color(0xffF6F8FC),

      // ============================================================
      // DRAWER
      // ============================================================
      drawer: _buildDrawer(user),

      // ============================================================
      // BODY
      // ============================================================
      body: RefreshIndicator(
        onRefresh: refreshDashboard,

        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),

          child: Column(
            children: [
              // ----------------------------------------------------
              // HEADER
              // ----------------------------------------------------
              DashboardHeader(
                userName: user?.name ?? "User",
                userRole: user?.roleName ?? "User",
                notificationCount: _unreadAlertCount,

                onMenuPressed: () {
                  _scaffoldKey.currentState?.openDrawer();
                },
              ),

              // ----------------------------------------------------
              // OVERVIEW
              // ----------------------------------------------------
              _buildOverview(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // ENVIRONMENT
              // ----------------------------------------------------
              _buildEnvironment(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // QUICK ACTIONS
              // ----------------------------------------------------
              _buildQuickActions(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // DEVICES
              // ----------------------------------------------------
              _buildDevices(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // ALERTS
              // ----------------------------------------------------
              _buildAlerts(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // INVENTORY
              // ----------------------------------------------------
              _buildInventorySummary(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // ORDER REQUESTS
              // ----------------------------------------------------
              _buildOrderSummary(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // BATCHES
              // ----------------------------------------------------
              _buildBatchSummary(),

              const SizedBox(height: 25),

              // ----------------------------------------------------
              // RECENT ACTIVITY
              // ----------------------------------------------------
              _buildRecentActivity(),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),

      // ============================================================
      // BOTTOM NAVIGATION
      // ============================================================
      bottomNavigationBar: BottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onBottomNavTap,
      ),
    );
  }

  // ================================================================
  // DRAWER
  // ================================================================

  Widget _buildDrawer(UserModel? user) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            // ============================================================
            // HEADER
            // ============================================================
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                gradient: AppColors.primaryGradient,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile Icon
                  const CircleAvatar(
                    radius: 34,
                    backgroundColor: Colors.white24,
                    child: Icon(Icons.person, size: 38, color: Colors.white),
                  ),

                  const SizedBox(height: 15),

                  // User Name
                  Text(
                    user?.name ?? "User",
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 5),

                  // Email
                  Text(
                    user?.email ?? "",
                    style: const TextStyle(color: Colors.white70, fontSize: 13),
                  ),

                  const SizedBox(height: 10),

                  // Role Badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      user?.roleName ?? "User",
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ============================================================
            // SCROLLABLE MENU
            // ============================================================
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  const SizedBox(height: 8),

                  // ======================================================
                  // DASHBOARD
                  // ======================================================
                  _drawerItem(
                    icon: Icons.dashboard_rounded,
                    title: "Dashboard",
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),

                  // ======================================================
                  // INVENTORY
                  // ======================================================
                  if (user != null &&
                      RolePermissions.canViewInventory(user.role))
                    _drawerItem(
                      icon: Icons.inventory_2_rounded,
                      title: "Inventory",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.inventory);
                      },
                    ),

                  // ======================================================
                  // SUPPLY MARKETPLACE
                  // PHARMACIST ONLY
                  // ======================================================
                  if (user != null &&
                      user.role == UserRole.pharmacist &&
                      RolePermissions.canViewOrderRequests(user.role))
                    _drawerItem(
                      icon: Icons.storefront_rounded,
                      title: "Supply Marketplace",
                      onTap: () {
                        Navigator.pop(context);
                        _openMarketplace();
                      },
                    ),

                  // ======================================================
                  // SUPPLIER PRODUCTS
                  // ADMIN / WAREHOUSE / SALES
                  // ======================================================
                  if (user != null &&
                      RolePermissions.canViewSupplierProducts(user.role))
                    _drawerItem(
                      icon: Icons.storefront_rounded,
                      title: "Supplier Products",
                      onTap: () {
                        Navigator.pop(context);
                        _openSupplierProducts();
                      },
                    ),

                  // ======================================================
                  // ORDER REQUESTS
                  // NON-PHARMACIST ORDERING ROLES
                  // ======================================================
                  if (user != null &&
                      user.role != UserRole.pharmacist &&
                      RolePermissions.canViewOrderRequests(user.role))
                    _drawerItem(
                      icon: Icons.shopping_cart_rounded,
                      title: "Order Requests",
                      onTap: () {
                        Navigator.pop(context);
                        _openOrderRequest();
                      },
                    ),

                  // ======================================================
                  // WASTE MANAGEMENT
                  // ======================================================
                  if (user != null && RolePermissions.canViewWaste(user.role))
                    _drawerItem(
                      icon: Icons.delete_sweep_rounded,
                      title: "Waste Management",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.waste);
                      },
                    ),

                  // ======================================================
                  // MAINTENANCE
                  // ======================================================
                  if (user != null &&
                      RolePermissions.canViewMaintenance(user.role))
                    _drawerItem(
                      icon: Icons.build_rounded,
                      title: "Maintenance",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.maintenance);
                      },
                    ),

                  // ======================================================
                  // REPORTS
                  // ======================================================
                  if (user != null && RolePermissions.canViewReports(user.role))
                    _drawerItem(
                      icon: Icons.bar_chart_rounded,
                      title: "Reports",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.reports);
                      },
                    ),

                  // ======================================================
                  // USER MANAGEMENT
                  // ADMIN ONLY
                  // ======================================================
                  if (user != null && RolePermissions.canManageUsers(user.role))
                    _drawerItem(
                      icon: Icons.manage_accounts_rounded,
                      title: "User Management",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.userManagement);
                      },
                    ),

                  // ======================================================
                  // DIVIDER
                  // ======================================================
                  const Divider(height: 25, indent: 16, endIndent: 16),

                  // ======================================================
                  // SETTINGS
                  // ======================================================
                  if (user != null &&
                      RolePermissions.canAccessSettings(user.role))
                    _drawerItem(
                      icon: Icons.settings_rounded,
                      title: "Settings",
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, AppRoutes.settings);
                      },
                    ),

                  // Extra bottom padding for scrolling
                  const SizedBox(height: 10),
                ],
              ),
            ),

            // ============================================================
            // FIXED BOTTOM SECTION
            // ============================================================
            const Divider(height: 1),

            // ============================================================
            // LOGOUT
            // ============================================================
            _drawerItem(
              icon: Icons.logout_rounded,
              title: "Logout",
              iconColor: Colors.red,
              textColor: Colors.red,
              onTap: _logout,
            ),

            // ============================================================
            // APP NAME
            // ============================================================
            const SizedBox(height: 5),

            const Text(
              "VaxiTrack Sri Lanka",
              style: TextStyle(color: Colors.grey, fontSize: 12),
            ),

            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  // ================================================================
  // DRAWER ITEM
  // ================================================================

  Widget _drawerItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? iconColor,
    Color? textColor,
  }) {
    return ListTile(
      dense: true,

      // Makes each menu item slightly more compact
      visualDensity: const VisualDensity(vertical: -1),

      contentPadding: const EdgeInsets.symmetric(horizontal: 16),

      leading: Icon(icon, color: iconColor ?? AppColors.primary, size: 21),

      title: Text(
        title,
        style: TextStyle(
          color: textColor ?? const Color(0xff30343B),
          fontWeight: FontWeight.w500,
          fontSize: 14,
        ),
      ),

      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 13,
        color: Colors.grey,
      ),

      onTap: onTap,
    );
  }
  // ================================================================
  // OVERVIEW
  // ================================================================

  Widget _buildOverview() {
    final user = currentUser;

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          const SectionHeader(
            icon: Icons.dashboard_rounded,
            title: "Overview",
            subtitle: "System health at a glance",
          ),

          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),

            crossAxisCount: 2,

            crossAxisSpacing: 15,
            mainAxisSpacing: 15,

            childAspectRatio: 0.85,

            children: [
              // ----------------------------------------------------
              // DEVICES
              // ----------------------------------------------------
              StatCard(
                title: "Devices",
                value: "24",
                subtitle: "22 Online",
                icon: Icons.memory,
                status: StatCardStatus.success,

                onTap: () {
                  if (user != null &&
                      RolePermissions.canViewDevices(user.role)) {
                    Navigator.pushNamed(context, AppRoutes.devices);
                  } else {
                    _showAccessDenied();
                  }
                },
              ),

              // ----------------------------------------------------
              // ALERTS
              // ----------------------------------------------------
              StatCard(
                title: "Alerts",
                value: _activeAlertCount.toString(),
                subtitle: "$_criticalAlertCount Critical",
                icon: Icons.warning_amber,
                status: _criticalAlertCount > 0
                    ? StatCardStatus.danger
                    : StatCardStatus.success,

                onTap: () {
                  Navigator.pushNamed(context, AppRoutes.alerts);
                },
              ),

              // ----------------------------------------------------
              // BATCHES
              // ----------------------------------------------------
              StatCard(
                title: "Batches",
                value: "12",
                subtitle: "Active",
                icon: Icons.vaccines,
                status: StatCardStatus.normal,

                onTap: () {
                  Navigator.pushNamed(context, AppRoutes.batches);
                },
              ),

              // ----------------------------------------------------
              // COMPLIANCE
              // ----------------------------------------------------
              const StatCard(
                title: "Compliance",
                value: "96%",
                subtitle: "Healthy",
                icon: Icons.health_and_safety,
                status: StatCardStatus.success,
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ================================================================
  // LIVE ENVIRONMENT
  // ================================================================

  Widget _buildEnvironment() {
    final user = currentUser;

    if (user == null || !RolePermissions.canViewDevices(user.role)) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          const SectionHeader(
            icon: Icons.sensors,
            title: "Live Environment",
            subtitle: "Real-time IoT sensor readings",
          ),

          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),

            crossAxisCount: 2,

            crossAxisSpacing: 15,
            mainAxisSpacing: 15,

            childAspectRatio: .85,

            children: const [
              SensorCard(
                title: "Temperature",
                value: "4.6",
                unit: "°C",
                icon: Icons.thermostat,
                description: "Safe Storage",
              ),

              SensorCard(
                title: "Humidity",
                value: "67",
                unit: "%",
                icon: Icons.water_drop,
                description: "Optimal",
              ),

              SensorCard(
                title: "Battery",
                value: "91",
                unit: "%",
                icon: Icons.battery_full,
                description: "Excellent",
              ),

              SensorCard(
                title: "Signal",
                value: "-63",
                unit: " dBm",
                icon: Icons.wifi,
                description: "Strong",
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ================================================================
  // QUICK ACTIONS
  // ================================================================

  Widget _buildQuickActions() {
    final user = currentUser;

    if (user == null) {
      return const SizedBox.shrink();
    }

    final actions = <Widget>[];

    // --------------------------------------------------------------
    // REGISTER DEVICE
    // --------------------------------------------------------------

    if (RolePermissions.canAddDevice(user.role)) {
      actions.add(
        QuickActionCard(
          title: "Register Device",
          subtitle: "Add new IoT device",
          icon: Icons.add_box_outlined,

          onTap: () {
            Navigator.pushNamed(context, AppRoutes.addDevice);
          },
        ),
      );
    }

    // --------------------------------------------------------------
    // ADD BATCH
    // --------------------------------------------------------------

    if (RolePermissions.canAddBatch(user.role)) {
      actions.add(
        QuickActionCard(
          title: "Add Batch",
          subtitle: "Create vaccine batch",
          icon: Icons.vaccines_outlined,

          onTap: () {
            Navigator.pushNamed(context, AppRoutes.addBatch);
          },
        ),
      );
    }

    // --------------------------------------------------------------
    // SCAN QR
    // --------------------------------------------------------------

    if (RolePermissions.canScanQR(user.role)) {
      actions.add(
        QuickActionCard(
          title: "Scan QR",
          subtitle: "Scan vaccine QR",
          icon: Icons.qr_code_scanner,

          onTap: () {
            // Add QR route here when QR page is implemented.
          },
        ),
      );
    }

    // --------------------------------------------------------------
    // INVENTORY
    // --------------------------------------------------------------

    if (RolePermissions.canViewInventory(user.role)) {
      actions.add(
        QuickActionCard(
          title: "Inventory",
          subtitle: "Manage vaccine stock",
          icon: Icons.inventory_2_outlined,

          onTap: () {
            Navigator.pushNamed(context, AppRoutes.inventory);
          },
        ),
      );
    }

    // ==============================================================
    // ORDER / MARKETPLACE ACTIONS
    // ==============================================================

    // --------------------------------------------------------------
    // PHARMACIST
    // --------------------------------------------------------------
    // Pharmacist gets Supply Marketplace.
    // --------------------------------------------------------------

    if (user.role == UserRole.pharmacist) {
      if (RolePermissions.canViewOrderRequests(user.role)) {
        actions.add(
          QuickActionCard(
            title: "Supply Marketplace",
            subtitle: "Browse & request products",
            icon: Icons.storefront_outlined,

            onTap: _openMarketplace,
          ),
        );
      }
    }
    // --------------------------------------------------------------
    // ADMIN / WAREHOUSE / SALES
    // --------------------------------------------------------------
    else {
      // ------------------------------------------------------------
      // SUPPLIER PRODUCTS
      // ------------------------------------------------------------

      if (RolePermissions.canViewSupplierProducts(user.role)) {
        actions.add(
          QuickActionCard(
            title: "Supplier Products",

            subtitle: user.role == UserRole.salesRepresentative
                ? "Showcase your products"
                : user.role == UserRole.warehouseStaff
                ? "Manage warehouse products"
                : "Manage marketplace",

            icon: Icons.storefront_outlined,

            onTap: _openSupplierProducts,
          ),
        );
      }

      // ------------------------------------------------------------
      // ORDER REQUESTS
      // ------------------------------------------------------------

      if (RolePermissions.canViewOrderRequests(user.role)) {
        actions.add(
          QuickActionCard(
            title: "Order Requests",
            subtitle: "Manage supply requests",
            icon: Icons.shopping_cart_outlined,

            onTap: _openOrderRequest,
          ),
        );
      }
    }

    // --------------------------------------------------------------
    // EMPTY
    // --------------------------------------------------------------

    if (actions.isEmpty) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          const SectionHeader(
            icon: Icons.flash_on,
            title: "Quick Actions",
            subtitle: "Available actions for your role",
          ),

          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),

            crossAxisCount: 2,

            crossAxisSpacing: 15,
            mainAxisSpacing: 15,

            childAspectRatio: .85,

            children: actions,
          ),
        ],
      ),
    );
  }

  // ================================================================
  // DEVICES
  // ================================================================

  Widget _buildDevices() {
    final user = currentUser;

    if (user == null || !RolePermissions.canViewDevices(user.role)) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        children: [
          SectionHeader(
            icon: Icons.memory,
            title: "Connected Devices",
            subtitle: "24 registered devices",
            actionText: "View All",

            onActionPressed: () {
              Navigator.pushNamed(context, AppRoutes.devices);
            },
          ),

          DeviceCard(
            deviceName: "ESP32 Cold Box A",
            location: "Colombo General Hospital",
            temperature: 4.8,
            humidity: 65,
            battery: 92,
            signal: 95,
            lastUpdated: "5 sec ago",
            status: DeviceStatus.online,
            onTap: () {},
          ),

          DeviceCard(
            deviceName: "ESP32 Cold Box B",
            location: "Kandy Regional Hospital",
            temperature: 8.5,
            humidity: 74,
            battery: 24,
            signal: 72,
            lastUpdated: "1 min ago",
            status: DeviceStatus.warning,
            onTap: () {},
          ),

          DeviceCard(
            deviceName: "ESP32 Cold Box C",
            location: "Jaffna MOH Office",
            temperature: 0,
            humidity: 0,
            battery: 0,
            signal: 0,
            lastUpdated: "18 min ago",
            status: DeviceStatus.offline,
            onTap: () {},
          ),
        ],
      ),
    );
  }

  // ================================================================
  // ALERTS
  // ================================================================

  Widget _buildAlerts() {
    final recentAlerts = _recentActiveAlerts;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          SectionHeader(
            icon: Icons.notifications_active,
            title: "Recent Alerts",
            subtitle: "$_activeAlertCount active alerts",
            actionText: "See All",
            onActionPressed: () {
              Navigator.pushNamed(context, AppRoutes.alerts);
            },
          ),
          if (recentAlerts.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 20),
              child: Text(
                "No active alerts. All systems are operating normally.",
                textAlign: TextAlign.center,
              ),
            )
          else
            ...recentAlerts.map(
              (alert) => AlertCard(
                title: alert.title,
                deviceName: alert.deviceName,
                location: alert.location,
                time: alert.time,
                severity: _dashboardSeverity(alert.severity),
                acknowledged: alert.acknowledged,
                onTap: () {
                  Navigator.pushNamed(context, AppRoutes.alerts);
                },
              ),
            ),
        ],
      ),
    );
  }

  // ================================================================
  // INVENTORY SUMMARY
  // ================================================================

  Widget _buildInventorySummary() {
    final user = currentUser;

    if (user == null || !RolePermissions.canViewInventory(user.role)) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        children: [
          SectionHeader(
            icon: Icons.inventory_2_rounded,
            title: "Inventory",
            subtitle: "Vaccine stock overview",
            actionText: "View All",

            onActionPressed: () {
              Navigator.pushNamed(context, AppRoutes.inventory);
            },
          ),

          Container(
            padding: const EdgeInsets.all(20),

            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),

            child: Row(
              children: [
                Expanded(
                  child: _inventoryItem(
                    Icons.vaccines,
                    "1,850",
                    "Available Doses",
                    Colors.green,
                  ),
                ),

                Expanded(
                  child: _inventoryItem(
                    Icons.warning_amber,
                    "3",
                    "Low Stock",
                    Colors.orange,
                  ),
                ),

                Expanded(
                  child: _inventoryItem(
                    Icons.error_outline,
                    "2",
                    "Expiring Soon",
                    Colors.red,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // INVENTORY ITEM
  // ================================================================

  Widget _inventoryItem(
    IconData icon,
    String value,
    String label,
    Color color,
  ) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),

        const SizedBox(height: 8),

        Text(
          value,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),

        const SizedBox(height: 4),

        Text(
          label,
          textAlign: TextAlign.center,

          style: const TextStyle(color: Colors.grey, fontSize: 11),
        ),
      ],
    );
  }

  // ================================================================
  // ORDER REQUEST SUMMARY
  // ================================================================

  Widget _buildOrderSummary() {
    final user = currentUser;

    if (user == null || !RolePermissions.canViewOrderRequests(user.role)) {
      return const SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        children: [
          SectionHeader(
            icon: Icons.shopping_cart_rounded,

            // Pharmacist sees marketplace terminology.
            title: user.role == UserRole.pharmacist
                ? "Supply Marketplace"
                : "Order Requests",

            subtitle: user.role == UserRole.pharmacist
                ? "Browse and request medical products"
                : "Vaccine supply requests",

            actionText: "View All",

            onActionPressed: _openOrderRequest,
          ),

          Container(
            padding: const EdgeInsets.all(20),

            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
            ),

            child: Column(
              children: [
                _orderRow("Pending", "5", Colors.orange, Icons.pending_actions),

                const Divider(),

                _orderRow(
                  "Approved",
                  "8",
                  Colors.blue,
                  Icons.check_circle_outline,
                ),

                const Divider(),

                _orderRow(
                  "Delivered",
                  "14",
                  Colors.green,
                  Icons.local_shipping_outlined,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================================================================
  // ORDER ROW
  // ================================================================

  Widget _orderRow(String title, String value, Color color, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: color),

        const SizedBox(width: 12),

        Expanded(
          child: Text(
            title,

            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ),

        Text(
          value,

          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ],
    );
  }

  // ================================================================
  // BATCH SUMMARY
  // ================================================================

  Widget _buildBatchSummary() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          SectionHeader(
            icon: Icons.vaccines,
            title: "Vaccine Batches",
            subtitle: "Cold chain inventory",
            actionText: "Manage",

            onActionPressed: () {
              Navigator.pushNamed(context, AppRoutes.batches);
            },
          ),

          BatchSummaryCard(
            batchName: "VX-2026-001",
            vaccineName: "Pfizer COVID-19",
            totalDoses: 1200,
            availableDoses: 980,
            expiryDate: "15 Aug 2026",
            status: BatchStatus.normal,
            onTap: () {},
          ),

          BatchSummaryCard(
            batchName: "VX-2026-002",
            vaccineName: "BCG Vaccine",
            totalDoses: 800,
            availableDoses: 120,
            expiryDate: "05 Jul 2026",
            status: BatchStatus.expiring,
            onTap: () {},
          ),

          BatchSummaryCard(
            batchName: "VX-2026-003",
            vaccineName: "MMR Vaccine",
            totalDoses: 650,
            availableDoses: 0,
            expiryDate: "28 Jun 2026",
            status: BatchStatus.expired,
            onTap: () {},
          ),
        ],
      ),
    );
  }

  // ================================================================
  // RECENT ACTIVITY
  // ================================================================

  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),

      child: Column(
        children: [
          const SectionHeader(
            icon: Icons.history,
            title: "Recent Activity",
            subtitle: "Latest system events",
            actionText: "View All",
          ),

          const ActivityTile(
            icon: Icons.memory,
            color: Colors.blue,
            title: "Device Connected",
            subtitle: "ESP32 Cold Box A came online.",
            time: "2 min ago",
          ),

          const ActivityTile(
            icon: Icons.thermostat,
            color: Colors.red,
            title: "Temperature Updated",
            subtitle: "Cold Room A reached 4.5°C.",
            time: "8 min ago",
          ),

          const ActivityTile(
            icon: Icons.vaccines,
            color: Colors.green,
            title: "Batch Registered",
            subtitle: "Pfizer Batch PF-2026-102 added.",
            time: "20 min ago",
          ),

          const ActivityTile(
            icon: Icons.check_circle,
            color: Colors.orange,
            title: "Alert Resolved",
            subtitle: "High temperature alert acknowledged.",
            time: "45 min ago",
          ),
        ],
      ),
    );
  }
}
